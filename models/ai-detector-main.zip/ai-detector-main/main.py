from fastapi import FastAPI, HTTPException
from .schema import TextRequest
import pickle
from model_utils import preprocess_text, extract_features, predict_text
import os 
import json
import asyncio
import aiohttp
from aio_pika import connect_robust, IncomingMessage
from dotenv import load_dotenv
load_dotenv()

RABBITMQ_URL= os.getenv("RABBITMQ_URL")
DJANGO_URL = os.getenv("DJANGO_URL")
app = FastAPI(title="Human vs AI Text Classifier")

# Load trained objects
with open('clf.pkl', 'rb') as f:
    clf = pickle.load(f)
with open('tfidf.pkl', 'rb') as f:
    tfidf = pickle.load(f)
with open('feature_columns.pkl', 'rb') as f:
    feature_columns = pickle.load(f)

async def process_message(message: IncomingMessage):
    async with message.process():
        try:
            payload = json.loads(message.body)
            job_id= payload.get("job_id")
            text_input= payload.get("text_input")
            if not text_input or not job_id:
                print(f"Invalid payload: {payload}")
                return
            print(f"processing job with {job_id}")
            result = predict_text(text_input, clf, tfidf, feature_columns)
            print(f"Result: {result}")
            async with aiohttp.ClientSession() as session:
                try:
                    response = await session.post(
                        DJANGO_URL, 
                        json={"job_id" : job_id, "result" : result},
                        timeout=10,
                    )
                    if response.status == 200:
                        print("result sent to django")
                    else:
                        print(f"error. Status code: {response.code}")
                except Exception as ex:
                    print(f"failed to send to django, error: {ex}")
                    raise ex
        except Exception as e:
            print(f"error: {e}")

async def rabbitmq_consumer():
    try:
        connection = await connect_robust(RABBITMQ_URL)
        channel = await connection.channel()
        queue = await channel.declare_queue("ml_jobs", durable=True)
        await queue.consume(process_message)
        return connection
    except Exception as e:
        print(f"error: {e}")
        raise e

@app.on_event("startup")
async def startup_event():
    app.state.rabbit_connection= await rabbitmq_consumer()

@app.on_event("shutdown")
async def shutdown_event():
    if hasattr(app.state, "rabbit_connection") and app.state.rabbit_connection:
        await app.state.rabbit_connection.close()

#/predict endpoint as fallback if rabbitmq fails
@app.post("/predict")
def predict_endpoint(request: TextRequest):
    if not request.text:
        raise HTTPException(status_code=400, detail="Text field is required")
    result = predict_text(request.text, clf, tfidf, feature_columns)
    return result
