from ninja import Schema
from datetime import datetime
from typing import Optional
class SignupSchema(Schema):
    username : str
    password1: str
    password2 : str
    email : str
    first_name : str
    last_name : str
    recaptcha_token : str

class LoginSchema(Schema):
    username : str
    password : str
    recaptcha_token : str

class TokenSchema(Schema):
    access: str
    refresh : str

class JobSchema(Schema):
    text: str

class UpdateJobSchema(Schema):
    job_id: int
    result : str

class MLJobSchema(Schema):
    job_id : int
    text : str
    status : str
    result : Optional[str]=None
    created_at: datetime