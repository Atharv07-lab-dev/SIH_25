import axios from "axios";
import type { Post, User, LoginCredentials } from "../types";

import { dummyPosts } from "../data/dummyData";

// Axios instance with base URL from env or default
const api = axios.create({
  baseURL:
    (import.meta as any).env?.VITE_API_BASE_URL ||
    "https://sih-django-777268942678.asia-south2.run.app/api/",
  withCredentials: false,
});

// Manage Authorization header
function setAuthHeader(token?: string) {
  if (token) {
    api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  } else {
    delete api.defaults.headers.common["Authorization"];
  }
}

// Initialize header from localStorage if present
try {
  const savedAccess = localStorage.getItem("accessToken");
  if (savedAccess) setAuthHeader(savedAccess);
} catch {}

// No-op reCAPTCHA for simplified flow
async function getRecaptchaToken(_: string): Promise<string> {
  return "";
}

// Dummy user data
const dummyUser: User = {
  id: "1",
  name: "John Doe",
  username: "johndoe",
  email: "john.doe@example.com",
  joinDate: "2024-01-15",
  postsAnalyzed: 1247,
  accuracyRate: 94.2,
};

// API Functions (currently returning dummy data)
export const postsApi = {
  // Fetch all posts
  getAllPosts: async (): Promise<Post[]> => {
    try {
      // Make a GET request to the API endpoint
      const response = await axios.get<any[]>(
        "https://jsonplaceholder.typicode.com/posts"
      );

      const newPosts: Post[] = [];

      for (let i = 0; i < response.data.length; i++) {
        newPosts.push({
          ...dummyPosts[i],
          id: response.data[i].id,
          content: response.data[i].title,
        });
      }

      return dummyPosts;
    } catch (error) {
      console.error("Error fetching posts:", error);
      // Re-throw the error to be handled by the caller
      throw new Error("Failed to fetch posts");
    }
  },

  verifyEmail: async (path: string) => {
    console.log(`Sending GET request to: ${path}`);

    // Make the GET request and return the promise
    return api.get(path);
  },

  getPostById: async (id: string): Promise<Post | null> => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 300));

      // In production:
      // const response = await api.get(`/posts/${id}`);
      // return response.data;

      return dummyPosts.find((post) => post.id === id) || null;
    } catch (error) {
      console.error("Error fetching post:", error);
      throw new Error("Failed to fetch post");
    }
  },

  // Authentication functions
  login: async (
    credentials: LoginCredentials & { recaptcha_token: string }
  ): Promise<{ user: User; token: string }> => {
    try {
      const response = await api.post("/login", credentials);

      const { access, refresh } = response.data as {
        access: string;
        refresh: string;
      };

      // Persist tokens and set header for future API calls
      localStorage.setItem("accessToken", access);
      localStorage.setItem("refreshToken", refresh);
      setAuthHeader(access);

      // In a real app, you would fetch the user profile from a /users/me endpoint.
      // For now, returning a dummy user is fine for UI continuity.
      if (response.data.access != null) {
        dummyUser.name = credentials.username;
        (dummyUser as any).username = credentials.username;
      }
      return {
        user: dummyUser,
        token: access,
      };
    } catch (error) {
      console.error("Error logging in:", error);
      // Reset tokens on failure
      localStorage.removeItem("accessToken");
      localStorage.removeItem("refreshToken");
      setAuthHeader("");
      throw new Error("Failed to login");
    }
  },

  signup: async (data: {
    username: string;
    first_name: string;
    last_name: string;
    email: string;
    password1: string;
    password2: string;
    recaptcha_token: string;
  }): Promise<{ message: string }> => {
    try {
      console.log({ data });
      const response = await api.post("/signup", data);
      console.log({ response });
      return response.data as { message: string };
    } catch (error: any) {
      // Attempt to parse and throw a more specific error from the backend
      const errorData = error.response?.data;
      if (errorData) {
        // Handle cases where backend sends structured errors (e.g., {"username": ["already exists"]})
        if (typeof errorData === "object") {
          const messages = Object.entries(errorData)
            .map(([key, value]) => `${key}: ${(value as string[]).join(", ")}`)
            .join("; ");
          throw new Error(
            messages || "Signup failed. Please check your input."
          );
        }
        // Handle simple error messages
        throw new Error(
          errorData.error ||
            errorData.detail ||
            "An unknown error occurred during signup."
        );
      }
      throw new Error("Failed to connect to the server.");
    }
  },

  logout: async (): Promise<void> => {
    try {
      await api.get("/logout");
    } finally {
      localStorage.removeItem("accessToken");
      localStorage.removeItem("refreshToken");
      setAuthHeader(undefined);
    }
  },

  // Get current user profile
  getCurrentUser: async (): Promise<User> => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 300));

      // In production:
      // const response = await api.get('/auth/me');
      // return response.data;

      return dummyUser;
    } catch (error) {
      console.error("Error fetching user:", error);
      throw new Error("Failed to fetch user");
    }
  },

  // Test URL for AI detection
  testUrl: async (url: string): Promise<void> => {
    try {
      console.log("Sending URL to backend for analysis:", url);
      await new Promise((resolve) => setTimeout(resolve, 500));

      // In production:
      // const response = await api.post('/analyze/url', { url });
      // return response.data;

      console.log("URL analysis request sent successfully");
    } catch (error) {
      console.error("Error testing URL:", error);
      throw new Error("Failed to test URL");
    }
  },
  refreshToken: async (): Promise<string | null> => {
    // 1. Get the refresh token from storage
    const refreshToken = localStorage.getItem("refreshToken");

    if (!refreshToken) {
      console.error("No refresh token found.");
      return null;
    }

    try {
      // 2. Make the POST request to the /refresh endpoint
      const response = await api.post<{ access: string }>("/refresh", {
        refresh: refreshToken,
      });

      const newAccessToken = response.data.access;

      // 3. Save the new access token
      localStorage.setItem("accessToken", newAccessToken);

      console.log("Access token refreshed successfully.");
      return newAccessToken;
    } catch (error) {
      console.error("Failed to refresh token:", error);
      // This usually means the refresh token is also expired, so you should log the user out.
      return null;
    }
  },
};

// Expose utility for UI components
export const authUtils = { getRecaptchaToken };
